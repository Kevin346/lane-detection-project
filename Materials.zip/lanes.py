#############################################################################
# Name: Kevin Flores                                                        #
# Program: lanes.py                                                         #
# Summary: This program is able to detect solid lanes upon a road and       #
# presents a visual indication that this is true.                           #
#############################################################################

# These lines of code simply imports openCV and numpy functions
import cv2
import numpy as np

#This function locates where the program may apply blue lines on the frame.
#These functions will locate the appropiate locations using the y intercept and the slope.
def make_coordinates(image, line_parameters):
    slope, intercept = line_parameters
    y1 = image.shape[0]
    y2 = int(y1*(3/5))
    x1 = int((y1 - intercept)/slope)
    x2 = int((y2 - intercept)/slope)
    return np.array([x1, y1, x2, y2])

#This function outputs the refined data of a new set of lines out of the average of the given data
def average_slope_intercept(image, lines):
    left_fit = []
    right_fit = []
    for line in lines:
        x1, y1, x2, y2 = line.reshape(4)
        parameters = np.polyfit((x1, x2), (y1, y2), 1)
        slope = parameters[0]
        intercept = parameters[1]
        if slope < 0:
            left_fit.append((slope, intercept))
        else:
            right_fit.append((slope, intercept))
    left_fit_average = np.average(left_fit, axis=0)
    right_fit_average = np.average(right_fit, axis=0)
    left_lane = make_coordinates(image, right_fit_average)
    right_lane = make_coordinates(image, left_fit_average)
    return np.array([left_lane, right_lane])

#Outputs an image the displays the noticable lines of an image
def canny(image):
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    canny_image = cv2.Canny(blur, 50, 150)
    return canny_image

#Displays a visual image of the data of two lines
def display_lines(image, lines):
    lined_image = np.zeros_like(image)
    if lines is not None:
        for x1, y1, x2, y2 in lines:
            cv2.line(lined_image, (x1, y1), (x2, y2), (255, 0, 0), 10)
    return lined_image

#Returns the region of the image that is of importance for further calculations
def region_of_interest(image):
    height = image.shape[0]
    polygons = np.array([
        [(200, height), (1100, height), (550, 250)]
    ])
    mask = np.zeros_like(image)
    cv2.fillPoly(mask, polygons, 255)
    masked_image = cv2.bitwise_and(image, mask)
    return masked_image

########## The 'center stage' of the operations. ##########

CAP = cv2.VideoCapture("test2.mp4")   #Acquires the video footage
while (CAP.isOpened()):                #Remains to loop as long as the video has not ended
    ret, frame = CAP.read()           #Recives a frame from the given video
    canny_image = canny(frame)        #Locates the lines of the image
    regional_image = region_of_interest(canny_image)  #Produces the interested region of the frame
    hough_lines = cv2.HoughLinesP(regional_image, 2, np.pi/180,  #Performs the hough transformation
                                  100, np.array([]), minLineLength=40, maxLineGap=5)
    averaged_lines = average_slope_intercept(frame, hough_lines) #Details an accpetable line from the hough data
    line_image = display_lines(frame, averaged_lines)            #Generates a frame of only the lines
    combo_image = cv2.addWeighted(frame, 0.8, line_image, 1, 1)  #Combines a frame of the videos and the generated lines 
    cv2.imshow("result", combo_image)  #Displays the video with the detected lanes in blue
    if cv2.waitKey(1) == ord('q'):     #Allows the option to exit the video
        break
CAP.release()                          #Closes the video
cv2.destroyAllWindows()                #Closes all windows

##########               End                  ##########